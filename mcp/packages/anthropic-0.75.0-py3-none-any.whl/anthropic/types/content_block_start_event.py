# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .raw_content_block_start_event import RawContentBlockStartEvent

__all__ = ["ContentBlockStartEvent"]

ContentBlockStartEvent = RawContentBlockStartEvent
"""The RawContentBlockStartEvent type should be used instead"""
